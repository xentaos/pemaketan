# xenta-base-common
[Paket] Paket Base Xenta OS pasangan casper &amp; ubiquity.
