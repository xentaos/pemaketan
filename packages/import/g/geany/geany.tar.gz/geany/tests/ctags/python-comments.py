
import foo ## as bug1

"hello" ## import bug2
"hi" # something # class bug3

for i in range(1, 2): ##class bug4
    pass ## class bug5
