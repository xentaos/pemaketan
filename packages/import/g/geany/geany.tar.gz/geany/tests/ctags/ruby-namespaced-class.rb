module A
  module B
  end
end

class A::B::C; end

puts A::B::C
