CREATE PROCEDURE "p1"(
)
BEGIN
        SET someting =  ChannelPath + '\' + ChannelName;
END;

CREATE PROCEDURE "p2"(
)
BEGIN
        SET someting =  '''' + ChannelPath + '''';
END;

CREATE PROCEDURE "p3"(
)
BEGIN
END;


