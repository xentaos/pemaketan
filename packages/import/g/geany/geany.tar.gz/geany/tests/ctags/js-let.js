let a = 1;
let b = 0;
let group = {
  x:1,
  y:1,
  z:1,
};
let func = function(){}
