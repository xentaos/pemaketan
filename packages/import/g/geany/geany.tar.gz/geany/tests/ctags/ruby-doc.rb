def f0; end

=begin
def bug1
end
=end

def f1; end

=begin 
def bug2
end
=end

def f2; end

=begin	def doesntcount end
def bug3
end
=end def notparsed end

def f3; end
