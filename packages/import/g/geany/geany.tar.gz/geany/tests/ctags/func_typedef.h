typedef SLIST_HEAD(symlist, symbol_node) symlist_t;
