-- Comment line
  -- Indented comment line
test = {}

function test.me_12a(one, two)
	print"me_12a"
end


 test.i_123 = function  (x)
	print"i_123"
end


test.me_12a(1,2)
test.i_123(1)
