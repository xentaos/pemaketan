
def plop
	[ 1, 2, 3, 4 ].each do |x|
		x > 0
	end.all?
end

def nothing
	puts "nothing"
end
