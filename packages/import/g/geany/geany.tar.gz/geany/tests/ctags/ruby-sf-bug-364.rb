class D
  def self.x?
  end
  def self.y!
  end
  def self.z=(a)
  end
  def self._a?
  end
  def self._b!
  end
  def self._c=(a)
  end
end
D._c=1
D.z=1
