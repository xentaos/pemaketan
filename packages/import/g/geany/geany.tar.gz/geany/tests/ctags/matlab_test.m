function [x,y,z] = func1 
function x = func2 
function func3 

