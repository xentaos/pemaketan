#!/usr/bin/env python

def main():
	
	return 0

if __name__ == '__main__': main()

var = 'hi'
var2 = 'hi' # blah = blah
