import java.util.Map;

public class bug814263 {
 protected java.util.Map map1;
 protected Map map2;
}
