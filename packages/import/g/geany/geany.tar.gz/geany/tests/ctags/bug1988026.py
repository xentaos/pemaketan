
class testClass:
    my_var = 0
    def main():
        pass

if __name__ == '__main__': testClass.main()
	def im_a_function():
	    pass
