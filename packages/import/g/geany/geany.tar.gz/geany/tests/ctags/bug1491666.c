typedef struct {
	int
		x;

	float
		y;
} my_struct;

void main (void) {
	my_struct var1;
	my_struct
		var2;
}
