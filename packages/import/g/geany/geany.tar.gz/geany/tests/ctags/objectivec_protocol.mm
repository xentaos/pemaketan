
@protocol Locking
- (void)lock;
- (void)unlock;
@end

