# geany
[Import] Paket import  Xenta OS Aplikasi Geany.  
Section: **import**  
