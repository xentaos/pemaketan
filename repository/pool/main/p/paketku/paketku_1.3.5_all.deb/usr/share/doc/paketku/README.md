# paketku

 Paket Contoh Buat Xenta OS Tim Pemaketan.
 Paketku merupakan sebuah paket contoh digunakan
 sebagai Pustaka Tim Pemaketan dari Xenta OS.
