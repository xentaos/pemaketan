# Xenta Welcome Screen
Aplikasi Pembuka Bawaan untuk Xenta OS</br></br>
<img src="https://github.com/xentaos/xenta-welcome-screen/blob/master/source/konsep/SLIDE%201%20Konsep.png">
</br></br>
Untuk chat disini aja <a href="https://gitter.im/Xenta-OS-dev/Lobby">Click Here</a>

Description: Paket Bawaan Sambutan Desktop Xenta OS.
 Bawaan Sambutan Desktop Xenta OS semua edisi.
