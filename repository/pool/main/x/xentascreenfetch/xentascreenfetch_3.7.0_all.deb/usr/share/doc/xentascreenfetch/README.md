![screenshot][logo]

[logo]: https://raw.githubusercontent.com/xentaos/xentacreenfetch/master/screenshot.png "screenshot"

# xentascreenfetch
Description: Paket Screeshot CLI Untuk Xenta OS.  
 Frok dari screenfetch dan di patch ditambahkan Logo
 Xenta OS.  
