# xenta-x-theme
Paket Bawaan Theme Xenta X untuk Xenta OS.  
Paket secara bawaan berupa GTK, Windows Sistem dan xfwm Theme.  
